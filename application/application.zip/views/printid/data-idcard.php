<div class="row wrapper border-bottom white-bg page-heading">
    <div class="col-lg-10">
        <h2>Print ID</h2>
        <ol class="breadcrumb">
            <li><a  href="<?php echo base_url('dashboard'); ?>">Dashboard</a></li>
            <li class="active"><strong><a>Print ID</a></strong></li>
        </ol>
    </div>
</div>
<div class="wrapper wrapper-content animated fadeIn">
    <div class="row">
        <div class="col-lg-12">
            <div class="ibox float-e-margins">
                <div class="ibox-title">
                    <h1>Print ID</h1>
                </div>
                </div>
            </div>
        </div>
    </div>